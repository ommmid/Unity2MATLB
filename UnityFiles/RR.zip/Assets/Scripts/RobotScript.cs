﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RobotScript : MonoBehaviour {

    public GameObject B;
    public GameObject B1;
	public float B1Angle; 
	public GameObject B2;
	public float B2Angle; 
    public GameObject B3;
    public float B3Angle; 
    public GameObject EE;

    // Use this for initialization
    void Start () {
        // Given a normalized (length 1) axis representation (x, y, z) and an angle A.
        //  Q = [sin(A/2)*x, sin(A/2)*y, sin(A/2)*z, cos(A/2)] (corresponding to [x, y, z, w])

        // this robot in Unity has already the reference configuraration applied, 
        // joint values [0 0 0] for this robot in Unity means it is in the refererence config and we do not need to 
        // apply the reference joint values here

        B1.transform.GetChild(1).transform.localPosition = new Vector3(0f, 0.2f, 0f);
        B1.transform.GetChild(1).transform.localRotation = Quaternion.AngleAxis(-90, new Vector3(1,0,0));
        B2.transform.GetChild(1).transform.localPosition = new Vector3(0f, 0.2f, 0f);
        B2.transform.GetChild(1).transform.localRotation = Quaternion.AngleAxis(-120, new Vector3(0.5774f, 0.5774f, 0.5774f));
        B3.transform.GetChild(1).transform.localPosition = new Vector3(0f, 0.2f, 0f);
        B3.transform.GetChild(1).transform.localRotation = Quaternion.AngleAxis(-90, new Vector3(1, 0, 0));
    }

    //Quaternion.Euler, the order is z, x, y
    // Returns a rotation that rotates z degrees around the z axis, x degrees around the x axis, and y degrees around the y axis 
    // (in that order)

    // Do not set one of the eulerAngles axis separately (eg. eulerAngles.x = 10; ) since this will lead to drift 
    // and undesired rotations. When setting them to a new value set them all at once as shown above. Unity will 
    // convert the angles to and from the rotation stored in Transform.rotation.

    // Update is called once per frame
    void Update () {

        B1.transform.position = B.transform.position; // world position
        B1.transform.localRotation = Quaternion.AngleAxis(-B1Angle, new Vector3(0, 1, 0));
        
        B2.transform.position = B1.transform.GetChild(1).transform.position; // world position
        B2.transform.rotation = B1.transform.GetChild(1).transform.rotation; // world orientation
        var B2Q = B2.transform.localRotation;
        B2.transform.localRotation = B2Q * Quaternion.AngleAxis(-B2Angle, new Vector3(0, 1, 0)); ;

        B3.transform.position = B2.transform.GetChild(1).transform.position; // world position
        B3.transform.rotation = B2.transform.GetChild(1).transform.rotation; // world orientation
        var B3Q = B3.transform.localRotation;
        B3.transform.localRotation = B3Q * Quaternion.AngleAxis(-B3Angle, new Vector3(0, 1, 0)); ;
    }
}