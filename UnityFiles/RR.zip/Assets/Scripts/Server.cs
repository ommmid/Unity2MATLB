﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net;
using System.Net.Sockets;
using System.Linq;
using System;
using System.IO;
using System.Text;

public class Server : MonoBehaviour {

    // Use this for initialization
    TcpListener listener;
    String msg;

    void Start()
    {
        listener = new TcpListener(IPAddress.Parse("0.0.0.0"), 55000);
        listener.Start();
        print("is listening");
    }

    // Update is called once per frame
    void Update()
    {
        
        if (!listener.Pending())
        {
        }
        else
        {
            print("socket comes");
            TcpClient client = listener.AcceptTcpClient();
            NetworkStream ns = client.GetStream();
            StreamReader reader = new StreamReader(ns);
            Debug.Log("reader -------------->" + reader.ToString());
           // msg = reader.ReadLine();
          //  print(msg);
        }
    }
}